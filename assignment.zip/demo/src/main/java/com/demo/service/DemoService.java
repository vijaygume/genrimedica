package com.demo.service;

import java.io.File;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.demo.entity.DemoEntity;

public interface DemoService {

	public List<DemoEntity> uploadFile(MultipartFile file);
	
	public List<DemoEntity> getAllData();
	
	public DemoEntity getByCode(String code);
	
	public void deleteAll();
	
	public File writeAllRecordsInCsv();
	
}
