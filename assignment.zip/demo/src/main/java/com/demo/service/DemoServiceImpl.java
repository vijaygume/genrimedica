package com.demo.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.demo.entity.DemoEntity;
import com.demo.repository.DemoJpaRepository;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class DemoServiceImpl implements DemoService {

	@Autowired
	private DemoJpaRepository demoJpaRepository;


	@Override
	public List<DemoEntity> uploadFile(MultipartFile file) {
		List<DemoEntity> entities = new ArrayList<>();

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));
			String headerLine = br.readLine();
			String newLine = null;
			while((newLine=br.readLine())!= null) {
				String[] attributeValues = newLine.split(",");

				DemoEntity enty = buildEntity(attributeValues);

				log.info("Entity: {}", enty.toString());

				entities.add(enty);
			}
		} catch (IOException e) {
			log.error("Error occurred while reading file");
			e.printStackTrace();
		}



		List<DemoEntity> repsonse = demoJpaRepository.saveAll(entities);

		return repsonse;
	}

	public DemoEntity buildEntity(String[] attributeValues) {

		return DemoEntity.builder().code(attributeValues[2]).codeListCode(attributeValues[1]).source(attributeValues[0])
				.displayValue(attributeValues[3]).longDescription(attributeValues[4])
				.fromDate(attributeValues[5]).toDate(attributeValues[6]).sortingPriority(attributeValues[7]).build();
	}

	@Override
	public List<DemoEntity> getAllData() {
		// 
		return demoJpaRepository.findAll();
	}

	@Override
	public DemoEntity getByCode(String code) {
		// TODO Auto-generated method stub
		return demoJpaRepository.findById(code).get();
	}

	@Override
	public void deleteAll() {

		demoJpaRepository.deleteAll();
	}

	@Override
	public File writeAllRecordsInCsv() {
		List<DemoEntity> entities = demoJpaRepository.findAll();
		File file = new File("new.csv");

		try {
			FileWriter writer = new FileWriter(file);

			writer.append("source");
			writer.append(",");
			writer.append("codeListCode");
			writer.append(",");
			writer.append("code");
			writer.append(",");
			writer.append("displayValue");
			writer.append(",");
			writer.append("longDescription");
			writer.append(",");
			writer.append("fromDate");
			writer.append(",");
			writer.append("toDate");
			writer.append(",");
			writer.append("sortingPriority");
			writer.append("\n");

			for(DemoEntity enty : entities) {
				writer.append(enty.getSource());
				writer.append(",");
				writer.append(enty.getCodeListCode());
				writer.append(",");
				writer.append(enty.getCode());
				writer.append(",");
				writer.append(enty.getDisplayValue());
				writer.append(",");
				writer.append(enty.getLongDescription());
				writer.append(",");
				writer.append(enty.getFromDate());
				writer.append(",");
				writer.append(enty.getToDate());
				writer.append(",");
				writer.append(enty.getSortingPriority());
				writer.append("\n");

			}

			writer.flush();
			writer.close();



		}
		catch(IOException e) {
			e.printStackTrace();
		}

		return file;


	}

}
