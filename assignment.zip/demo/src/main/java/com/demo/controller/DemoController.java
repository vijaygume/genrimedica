package com.demo.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.demo.entity.DemoEntity;
import com.demo.service.DemoService;

@RestController
@RequestMapping("/test")
public class DemoController {


	@Autowired
	private DemoService demoService;

	@PostMapping("/upload")
	public ResponseEntity<List<DemoEntity>> uploadFile(@RequestParam("file") MultipartFile multipartFile){


		return new ResponseEntity<List<DemoEntity>>(demoService.uploadFile(multipartFile),HttpStatus.OK);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<DemoEntity>> getAll(){


		return new ResponseEntity<List<DemoEntity>>(demoService.getAllData(),HttpStatus.OK);
	}

	@GetMapping("/getByCode/{code}")
	public DemoEntity getByCode(@PathVariable("code") String code){


		return demoService.getByCode(code);
	}

	@DeleteMapping("/deleteAll")
	public ResponseEntity<String> deleteAll(){	

		demoService.deleteAll();

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping("/download")
	public ResponseEntity<Resource> download() throws FileNotFoundException{
		File file = demoService.writeAllRecordsInCsv();

		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=new.csv")
				.contentType(MediaType.parseMediaType("application/csv")).contentLength(file.length()).body(resource);
	}



}
