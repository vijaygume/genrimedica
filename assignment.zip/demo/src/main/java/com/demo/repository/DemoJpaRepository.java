package com.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.entity.DemoEntity;
@Repository
public interface DemoJpaRepository extends JpaRepository<DemoEntity, String> {

	
	
}
