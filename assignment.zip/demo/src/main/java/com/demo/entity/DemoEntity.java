package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="sample_table")
public class DemoEntity {

	@Id
	@Column
	private String code;
	
	@Column
	private String source;
	
	@Column
	private String codeListCode;	
	
	@Column
	private String displayValue;
	
	@Column
	private String longDescription;
	
	@Column
	private String fromDate;
	
	@Column
	private String toDate;
	
	@Column
	private String sortingPriority;
}
